#!/bin/sh

INSTPREFIX="/opt/cisco/vpn"
ROOTCERTSTORE=/opt/.cisco/certificates/ca
ROOTCACERT="VeriSignClass3PublicPrimaryCertificationAuthority-G5.pem"
BINDIR="${INSTPREFIX}/bin"
LIBDIR="${INSTPREFIX}/lib"
PROFDIR="${INSTPREFIX}/profile"
SCDIR="/usr/share/applications"
INIT="vpnagentd_init"
SYSVSTART="S85"
SYSVSTOP="K25"
SYSVLEVELS="2 3 4 5"

# List of files to remove
FILELIST="${BINDIR}/vpnagentd \
          ${BINDIR}/vpn_uninstall.sh \
          ${LIBDIR}/libssl.so.0.9.8 \
          ${LIBDIR}/libcrypto.so.0.9.8 \
          ${BINDIR}/vpnui \
          ${BINDIR}/vpn \
          ${BINDIR}/vpndownloader \
          ${BINDIR}/vpndownloader.sh \
          ${SCDIR}/anyconnect.desktop \
          ${INSTPREFIX}/pixmaps/* \
          ${INSTPREFIX}/VPNManifestClient.xml \
          ${INSTPREFIX}/update.txt \
          ${PROFDIR}/AnyConnectProfile.tmpl \
          ${PROFDIR}/AnyConnectProfile.xsd \
          ${ROOTCERTSTORE}/${ROOTCACERT}"

OPTIONAL_FILELIST="vpndownloader_nogui \
          ${BINDIR}/manifesttool"

echo "Uninstalling Cisco AnyConnect VPN Client ..."
echo "Uninstalling Cisco AnyConnect VPN Client ..." > /tmp/vpn-uninstall.log
echo `whoami` "invoked $0 from " `pwd` " at " `date` >> /tmp/vpn-uninstall.log

# Check for root privileges
if [ `id | sed -e 's/(.*//'` != "uid=0" ]; then
  echo "Sorry, you need super user privileges to run this script."
  echo "Sorry, you need super user privileges to run this script." >> /tmp/vpn-uninstall.log
  exit 1
fi

# update the VPNManifestClient.xml; if no entries remain in the .dat file then
# this tool will delete the file - DO NOT blindly delete VPNManifest.dat by
# adding it to the FILELIST above- allow this tool to delete the file if needed
if [ -e ${BINDIR}/manifesttool ]; then
    echo "manifesttool -x ${INSTPREFIX} ${INSTPREFIX}/VPNManifestClient.xml" >> /tmp/vpn-uninstall.log
    ${BINDIR}/manifesttool -x ${INSTPREFIX} ${INSTPREFIX}/VPNManifestClient.xml
fi

# Remove those pre-deploy files that we may have installed
for FILE in ${OPTIONAL_FILELIST}; do
  if [ -e ${FILE} ]; then
    echo "rm -f ${FILE}" >> /tmp/vpn-uninstall.log
    rm -f ${FILE} >> /tmp/vpn-uninstall.log 2>&1
  fi
done

# Remove only those files that we know we installed
for FILE in ${FILELIST}; do
  echo "rm -f ${FILE}" >> /tmp/vpn-uninstall.log
  rm -f ${FILE} >> /tmp/vpn-uninstall.log 2>&1
done

# Remove the cert store directory if it is empty
echo "rmdir --ignore-fail-on-non-empty ${ROOTCERTSTORE}" >> /tmp/vpn-uninstall.log
rmdir --ignore-fail-on-non-empty ${ROOTCERTSTORE} >> /tmp/vpn-uninstall.log 2>&1

# update the menu cache so that the AnyConnect short cut in the
# applications menu is removed. This is neccessary on some
# gnome desktops(Ubuntu 10.04)
if [ -x "/usr/share/gnome-menus/update-gnome-menus-cache" ]; then
    for CACHE_FILE in $(ls /usr/share/applications/desktop.*.cache); do
        echo "updating ${CACHE_FILE}" >> /tmp/vpn-uninstall.log
        /usr/share/gnome-menus/update-gnome-menus-cache /usr/share/applications/ > ${CACHE_FILE}
    done
fi

# If our custom lib directory is empty, remove it
#if [ `ls ${LIBDIR} | wc -l` -eq 0 ]; then
#  rmdir ${LIBDIR}
#fi

# We need to check for, and try to remove, our init script.
if [ `chkconfig --list 2> /dev/null | wc -l` -gt 0 ]; then
  chkconfig --del ${INIT} # We don't exit on error in case user manually
                          # removed from chkconfig
fi

if [ -e "/etc/init.d/${INIT}" ]; then
  INITD="/etc/init.d"
elif [ -e "/etc/rc.d/init.d/${INIT}" ]; then
  INITD="/etc/rc.d/init.d"
else
  INITD="/etc/rc.d"
fi

if [ -d "/etc/rc.d" ]; then
  RCD="/etc/rc.d"
else
  RCD="/etc"
fi

# Make sure our runlevel symlinks are removed, in case of BSD-style init
for LEVEL in ${SYSVLEVELS}; do
  DIR="rc${LEVEL}.d"
  if [ -d "${RCD}/${DIR}" ]; then
    echo "rm -f ${RCD}/${DIR}/${SYSVSTART}${INIT}" >> /tmp/vpn-uninstall.log
    rm -f ${RCD}/${DIR}/${SYSVSTART}${INIT}
    echo "rm -f ${RCD}/${DIR}/${SYSVSTOP}${INIT}" >> /tmp/vpn-uninstall.log
    rm -f ${RCD}/${DIR}/${SYSVSTOP}${INIT}
  fi
done

# Attempt to stop the service if it is running, and remove the init script.
if [ "x${INITD}" != "x" ]; then
  echo "Stopping the VPN agent..." >> /tmp/vpn-uninstall.log
  echo "${INITD}/${INIT} stop" >> /tmp/vpn-uninstall.log
  ${INITD}/${INIT} stop >> /tmp/vpn-uninstall.log
  echo "rm ${INITD}/${INIT}" >> /tmp/vpn-uninstall.log
  logger "Stopping the VPN agent..."

  max_seconds_to_wait=10
  ntests=$max_seconds_to_wait
  # wait for socket to which agent is listening to close
  if ! which nc > /dev/null 2>&1 ; then
    # just sleep if nc utility is not available
    sleep $max_seconds_to_wait
  else
    while nc -z 127.0.0.1 29754 > /dev/null 2>&1
    do
      ntests=`expr  $ntests - 1`
      if [ $ntests -eq 0 ]; then
          logger "Timeout waiting for agent to stop."
          echo "Timeout waiting for agent to stop." >> /tmp/vpn-uninstall.log
          break
      fi
      sleep 1
    done
  fi
  
  rm ${INITD}/${INIT} || echo "Warning: unable to remove init script"
fi

# ensure that the agent, gui and cli are not running
OURPROCS=`ps -A -o pid,command | grep '/opt/cisco/vpn/bin' | egrep -v 'grep|vpn_uninstall' | cut -c 1-5`
if [ -n "${OURPROCS}" ] ; then
    for DOOMED in ${OURPROCS}; do
        echo Killing `ps -A -o pid,command -p ${DOOMED} | grep ${DOOMED} | egrep -v 'ps|grep'` >> /tmp/vpn-uninstall.log
        kill -KILL ${DOOMED} >> /tmp/vpn-uninstall.log 2>&1
    done
fi

echo "Successfully removed AnyConnect from system." >> /tmp/vpn-uninstall.log
echo "Successfully removed AnyConnect from system."
exit 0

